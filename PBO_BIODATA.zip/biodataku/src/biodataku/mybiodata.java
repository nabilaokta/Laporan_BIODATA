import java.util.Scanner;

public class mybiodata {
    public static  void main (String[] args) {
        Scanner input = new Scanner (System.in);
        
        String nama;
        String kelas;
        String sekolah;
        String ttl;
        String alamat;
        String hoby;
        
        System.out.print ("Masukan Nama.../n");
        nama = input.nextLine ();
        System.out.print ("Masukan kelas.../n");
        kelas = input.nextLine ();
        System.out.print ("Masukan sekolah.../n");
        sekolah = input.nextLine ();
        System.out.print ("Masukan Tempat Tanggal Lahir.../n");
        ttl = input.nextLine ();
        System.out.print ("Masukan Alamat.../n");
        alamat = input.nextLine ();
        System.out.print ("Masukan Hoby.../n");
        hoby = input.nextLine ();
        
        
        System.out.println ("=====BIODATAKU=====");
        System.out.println ("Nama                           :" + nama);
        System.out.println ("Kelas                          :" +kelas);
        System.out.println ("Sekolah                        :" +sekolah);
        System.out.println ("Tempat Tanggal Lahir           :" +ttl);
        System.out.println ("Alamat                         :" +alamat);
        System.out.println ("Hoby                           :" +hoby);    
    } 
}
